# Security Implementation for Shram Bhoj

## Overview
This document outlines the security measures implemented for the Shram Bhoj MVP application.

## Database Security (Supabase RLS)

### Table Protection

#### Workers Table
- **RLS Enabled**: Yes
- **SELECT Policy**: Public can only view available workers (`availability = 'available'`)
- **INSERT Policy**: Anyone can register (required for onboarding)
- **UPDATE Policy**: Any authenticated request can update (simplified for MVP without auth)

#### Employers Table
- **RLS Enabled**: Yes
- **SELECT Policy**: Public can view employer basic info
- **INSERT Policy**: Anyone can register (required for posting jobs)
- **UPDATE Policy**: Any authenticated request can update (simplified for MVP without auth)

#### Jobs Table
- **RLS Enabled**: Yes
- **SELECT Policy**: Public can only view open jobs (`status = 'open'`)
- **INSERT Policy**: Anyone can post jobs
- **UPDATE Policy**: Job owners can update (simplified for MVP without auth)

#### Applications Table
- **RLS Enabled**: Yes
- **SELECT Policy**: Public can view (for MVP transparency)
- **INSERT Policy**: Workers can apply to jobs
- **UPDATE Policy**: Only involved parties should update (simplified for MVP)

**Note**: In a production environment with proper authentication, these policies would use `auth.uid()` and JWT claims to enforce strict ownership. For the MVP without auth infrastructure, we've implemented the most restrictive policies feasible.

## Input Validation & Sanitization

### Phone Numbers
- Validated against Indian mobile patterns (10 digits, starts with 6-9)
- Sanitized to remove non-digit characters
- Maximum length enforced (10 digits)

### Aadhaar Numbers
- Validated as 12-digit numbers
- Sanitized to remove non-digit characters
- Maximum length enforced (12 digits)

### Names
- Validated: 2-50 characters
- Allowed: letters, spaces, Devanagari script (for Hindi names)
- Sanitized against XSS (HTML entity encoding)

### Budget
- Validated: positive number up to ₹1,00,00,000
- Sanitized to numeric values only

### Years of Experience
- Validated: 0-50 years
- Sanitized to integers only

### Skill Level
- Validated: 1-5 scale

### Text Inputs
- All text fields sanitized with HTML entity encoding
- Prevents XSS attacks
- Trimmed whitespace

## Frontend Security Measures

### Input Constraints
- `maxLength` attributes on all text inputs
- `min`/`max` attributes on numeric inputs
- Input masking for phone and Aadhaar numbers

### Data Handling
- All data sanitized before database insertion
- Validation errors shown to users
- Phone numbers validated against Indian mobile patterns

### UI Security
- No sensitive data stored in localStorage (only profile IDs)
- No API keys exposed in client code
- Environment variables used for Supabase credentials

## Known MVP Limitations

### Authentication
- No real user authentication implemented (MVP uses mock auth)
- Production requires: Supabase Auth with phone OTP or JWT tokens
- This would enable proper ownership checks in RLS policies

### RLS Policies
- UPDATE policies are permissive due to lack of auth
- In production, would use: `USING (auth.uid() = id)`
- Current policies are as restrictive as possible without auth

### Session Management
- localStorage used for session persistence
- In production: use secure HTTP-only cookies with JWT
- Implement proper session timeout

## Production Recommendations

1. **Enable Supabase Auth**
   - Phone OTP authentication
   - JWT token management
   - Session handling

2. **Strengthen RLS Policies**
   - Replace `USING (true)` with `USING (auth.uid() = user_id)`
   - Add phone number verification
   - Implement proper employer verification

3. **Add Rate Limiting**
   - Limit job posts per employer per day
   - Limit applications per worker per hour
   - Prevent spam and abuse

4. **Implement CSRF Protection**
   - Use CSRF tokens
   - Validate origin headers

5. **Add Content Security Policy**
   - Restrict script sources
   - Prevent inline scripts

6. **Audit Logging**
   - Log all profile updates
   - Track job postings and applications
   - Monitor for suspicious activity

7. **Data Encryption**
   - Encrypt Aadhaar numbers at rest
   - Use Supabase Vault for sensitive data

## Security Testing Checklist

- [x] RLS policies tested (public cannot access unavailable workers)
- [x] Input validation tested (invalid phone numbers rejected)
- [x] XSS prevention tested (HTML entities sanitized)
- [x] SQL injection prevented (using Supabase client, parameterized queries)
- [x] Build passes without errors
- [ ] Authentication flow tested (requires auth implementation)
- [ ] Rate limiting tested (requires implementation)
- [ ] CSRF protection tested (requires implementation)
