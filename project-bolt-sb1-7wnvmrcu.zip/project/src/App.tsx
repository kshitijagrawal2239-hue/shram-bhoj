import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import Toast from './components/Toast';
import Navigation from './components/Navigation';
import LandingPage from './pages/LandingPage';
import WorkerOnboarding from './pages/WorkerOnboarding';
import PostJob from './pages/PostJob';
import WorkersPage from './pages/WorkersPage';
import FindWorkPage from './pages/FindWorkPage';
import Dashboard from './pages/Dashboard';

function App() {
  return (
    <AppProvider>
      <Router>
        <div className="min-h-screen bg-gray-50">
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/worker-onboarding" element={<WorkerOnboarding />} />
            <Route path="/post-job" element={<PostJob />} />
            <Route path="/workers" element={<WorkersPage />} />
            <Route path="/find-work" element={<FindWorkPage />} />
            <Route path="/dashboard" element={<Dashboard />} />
          </Routes>
          <Navigation />
          <Toast />
        </div>
      </Router>
    </AppProvider>
  );
}

export default App;
