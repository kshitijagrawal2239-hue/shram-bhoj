import { Link, useLocation } from 'react-router-dom';
import { Home, Briefcase, PlusCircle, User, Search } from 'lucide-react';
import { useApp } from '../context/AppContext';

export default function Navigation() {
  const location = useLocation();
  const { userType } = useApp();

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <>
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-40 md:hidden">
        <div className="flex items-center justify-around h-16">
          <Link
            to="/"
            className={`flex flex-col items-center justify-center w-full h-full ${
              isActive('/') ? 'text-primary-500' : 'text-gray-500'
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-xs mt-1">Home</span>
          </Link>

          {userType === 'worker' && (
            <Link
              to="/find-work"
              className={`flex flex-col items-center justify-center w-full h-full ${
                isActive('/find-work') ? 'text-primary-500' : 'text-gray-500'
              }`}
            >
              <Search className="w-5 h-5" />
              <span className="text-xs mt-1">Find Work</span>
            </Link>
          )}

          {userType === 'employer' && (
            <Link
              to="/workers"
              className={`flex flex-col items-center justify-center w-full h-full ${
                isActive('/workers') ? 'text-primary-500' : 'text-gray-500'
              }`}
            >
              <Search className="w-5 h-5" />
              <span className="text-xs mt-1">Find Workers</span>
            </Link>
          )}

          {userType === 'employer' && (
            <Link
              to="/post-job"
              className={`flex flex-col items-center justify-center w-full h-full ${
                isActive('/post-job') ? 'text-primary-500' : 'text-gray-500'
              }`}
            >
              <PlusCircle className="w-5 h-5" />
              <span className="text-xs mt-1">Post Job</span>
            </Link>
          )}

          <Link
            to="/dashboard"
            className={`flex flex-col items-center justify-center w-full h-full ${
              isActive('/dashboard') ? 'text-primary-500' : 'text-gray-500'
            }`}
          >
            <User className="w-5 h-5" />
            <span className="text-xs mt-1">Profile</span>
          </Link>
        </div>
      </nav>

      <div className="h-16 md:hidden" />
    </>
  );
}
