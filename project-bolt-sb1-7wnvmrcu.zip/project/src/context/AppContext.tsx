import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase, Worker, Employer, Job } from '../lib/supabase';

type UserType = 'worker' | 'employer' | null;

interface AppContextType {
  userType: UserType;
  setUserType: (type: UserType) => void;
  worker: Worker | null;
  setWorker: (worker: Worker | null) => void;
  employer: Employer | null;
  setEmployer: (employer: Employer | null) => void;
  loading: boolean;
  toast: { message: string; type: 'success' | 'error' } | null;
  showToast: (message: string, type: 'success' | 'error') => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [userType, setUserType] = useState<UserType>(() => {
    const stored = localStorage.getItem('shram_user_type');
    return stored as UserType;
  });

  const [worker, setWorker] = useState<Worker | null>(() => {
    const stored = localStorage.getItem('shram_worker');
    return stored ? JSON.parse(stored) : null;
  });

  const [employer, setEmployer] = useState<Employer | null>(() => {
    const stored = localStorage.getItem('shram_employer');
    return stored ? JSON.parse(stored) : null;
  });

  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  useEffect(() => {
    if (userType) {
      localStorage.setItem('shram_user_type', userType);
    } else {
      localStorage.removeItem('shram_user_type');
    }
  }, [userType]);

  useEffect(() => {
    if (worker) {
      localStorage.setItem('shram_worker', JSON.stringify(worker));
    } else {
      localStorage.removeItem('shram_worker');
    }
  }, [worker]);

  useEffect(() => {
    if (employer) {
      localStorage.setItem('shram_employer', JSON.stringify(employer));
    } else {
      localStorage.removeItem('shram_employer');
    }
  }, [employer]);

  const showToast = (message: string, type: 'success' | 'error') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  return (
    <AppContext.Provider value={{
      userType,
      setUserType,
      worker,
      setWorker,
      employer,
      setEmployer,
      loading,
      toast,
      showToast,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
