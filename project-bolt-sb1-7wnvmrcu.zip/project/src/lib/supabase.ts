import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Utility functions for data validation and sanitization
export function validatePhone(phone: string): boolean {
  // Indian phone number: 10 digits
  const phoneRegex = /^[6-9]\d{9}$/;
  return phoneRegex.test(phone.replace(/\s/g, ''));
}

export function sanitizePhone(phone: string): string {
  // Remove all non-digit characters
  return phone.replace(/\D/g, '').slice(0, 10);
}

export function validateAadhaar(aadhaar: string): boolean {
  // 12 digit Aadhaar number
  const aadhaarRegex = /^\d{12}$/;
  return aadhaarRegex.test(aadhaar);
}

export function sanitizeAadhaar(aadhaar: string): string {
  return aadhaar.replace(/\D/g, '').slice(0, 12);
}

export function sanitizeText(text: string): string {
  // Remove potentially dangerous characters
  return text
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;')
    .trim();
}

export function validateName(name: string): boolean {
  // Name should be at least 2 characters, only letters, spaces, and common Indian name characters
  const nameRegex = /^[a-zA-Z\s\u0900-\u097F]{2,50}$/;
  return nameRegex.test(name.trim());
}

export function validateBudget(budget: number): boolean {
  // Budget should be positive and reasonable (up to 1 crore)
  return budget > 0 && budget <= 10000000;
}

export function validateYears(years: number): boolean {
  return years >= 0 && years <= 50;
}

export function validateSkillLevel(level: number): boolean {
  return level >= 1 && level <= 5;
}

export type Worker = {
  id: string;
  name: string;
  phone: string;
  city: string;
  area?: string;
  trade: string;
  years_experience: number;
  skill_level: number;
  rating: number;
  jobs_completed: number;
  verified: boolean;
  aadhaar_number?: string;
  availability: 'available' | 'busy' | 'unavailable';
  created_at: string;
};

export type Employer = {
  id: string;
  name: string;
  phone: string;
  company_name?: string;
  city: string;
  created_at: string;
};

export type Job = {
  id: string;
  employer_id: string;
  title: string;
  trade_required: string;
  city: string;
  area?: string;
  duration: string;
  budget: number;
  urgency: 'urgent' | 'flexible';
  contact_number: string;
  status: 'open' | 'filled' | 'closed' | 'cancelled';
  created_at: string;
};

export type Application = {
  id: string;
  job_id: string;
  worker_id: string;
  status: 'pending' | 'accepted' | 'rejected' | 'withdrawn';
  created_at: string;
};
