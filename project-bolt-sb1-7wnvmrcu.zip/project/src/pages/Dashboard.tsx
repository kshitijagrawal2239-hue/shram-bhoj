import { useApp } from '../context/AppContext';
import WorkerDashboard from './WorkerDashboard';
import EmployerDashboard from './EmployerDashboard';

export default function Dashboard() {
  const { userType } = useApp();

  if (userType === 'worker') {
    return <WorkerDashboard />;
  }

  return <EmployerDashboard />;
}
