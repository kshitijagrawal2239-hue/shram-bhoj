import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { User, Briefcase, PlusCircle, Clock, MapPin, Star, Shield, ArrowRight, Users, Zap } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { supabase, Job, Worker } from '../lib/supabase';

const DUMMY_JOBS: Job[] = [
  {
    id: 'job-1',
    employer_id: 'emp-1',
    title: 'Kitchen pipe repair',
    trade_required: 'Plumber',
    city: 'Surat',
    area: 'Varachha',
    duration: '3 hours',
    budget: 800,
    urgency: 'urgent',
    contact_number: '98XXXXXXXX',
    status: 'open',
    created_at: new Date().toISOString(),
  },
  {
    id: 'job-2',
    employer_id: 'emp-2',
    title: 'Full house wiring',
    trade_required: 'Electrician',
    city: 'Surat',
    area: 'Adajan',
    duration: '3 days',
    budget: 12000,
    urgency: 'flexible',
    contact_number: '97XXXXXXXX',
    status: 'open',
    created_at: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
  },
];

const DUMMY_APPLICANTS: Worker[] = [
  {
    id: 'applicant-1',
    name: 'Ramesh Patel',
    trade: 'Plumber',
    city: 'Surat',
    area: 'Varachha',
    rating: 4.7,
    jobs_completed: 43,
    verified: true,
    years_experience: 8,
    phone: '98XXXXXXXX',
    skill_level: 4,
    availability: 'available',
    created_at: new Date().toISOString(),
  },
  {
    id: 'applicant-2',
    name: 'Sunil Kumar',
    trade: 'Plumber',
    city: 'Surat',
    area: 'Katargam',
    rating: 4.5,
    jobs_completed: 31,
    verified: true,
    years_experience: 5,
    phone: '97XXXXXXXX',
    skill_level: 4,
    availability: 'available',
    created_at: new Date().toISOString(),
  },
  {
    id: 'applicant-3',
    name: 'Anil Sharma',
    trade: 'Electrician',
    city: 'Surat',
    area: 'Ring Road',
    rating: 4.3,
    jobs_completed: 28,
    verified: true,
    years_experience: 6,
    phone: '96XXXXXXXX',
    skill_level: 4,
    availability: 'available',
    created_at: new Date().toISOString(),
  },
];

export default function EmployerDashboard() {
  const { employer, setEmployer } = useApp();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [applicants, setApplicants] = useState<Map<string, Worker[]>>(new Map());
  const [loading, setLoadState] = useState(true);

  useEffect(() => {
    fetchData();
  }, [employer]);

  const fetchData = async () => {
    try {
      let employerId = employer?.id;

      if (!employer) {
        const storedEmployer = localStorage.getItem('shram_employer');
        if (storedEmployer) {
          const parsed = JSON.parse(storedEmployer);
          employerId = parsed.id;
          setEmployer(parsed);
        }
      }

      if (employerId) {
        const { data: jobsData } = await supabase
          .from('jobs')
          .select('*')
          .eq('employer_id', employerId)
          .order('created_at', { ascending: false })
          .limit(10);

        if (jobsData && jobsData.length > 0) {
          setJobs(jobsData);

          const applicantMap = new Map<string, Worker[]>();
          jobsData.forEach(job => {
            applicantMap.set(job.id, DUMMY_APPLICANTS.slice(0, 2 + Math.floor(Math.random() * 2)));
          });
          setApplicants(applicantMap);
        } else {
          setJobs(DUMMY_JOBS);
          const applicantMap = new Map<string, Worker[]>();
          DUMMY_JOBS.forEach(job => {
            applicantMap.set(job.id, DUMMY_APPLICANTS.filter(a => a.trade === job.trade_required).slice(0, 2));
          });
          setApplicants(applicantMap);
        }
      } else {
        setJobs(DUMMY_JOBS);
        const applicantMap = new Map<string, Worker[]>();
        DUMMY_JOBS.forEach(job => {
          applicantMap.set(job.id, DUMMY_APPLICANTS.filter(a => a.trade === job.trade_required).slice(0, 2));
        });
        setApplicants(applicantMap);
      }
    } catch (err) {
      setJobs(DUMMY_JOBS);
    } finally {
      setLoadState(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open':
        return 'bg-green-100 text-green-700';
      case 'filled':
        return 'bg-blue-100 text-blue-700';
      case 'closed':
        return 'bg-gray-100 text-gray-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      <header className="px-4 py-4 bg-white border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold text-gray-900">Dashboard</h1>
          <Link
            to="/post-job"
            className="flex items-center gap-2 px-4 py-2 bg-primary-500 text-white rounded-lg font-medium hover:bg-primary-600 transition-all min-h-[36px]"
          >
            <PlusCircle className="w-4 h-4" />
            Post Job
          </Link>
        </div>
      </header>

      <div className="px-4 py-6 max-w-4xl mx-auto space-y-6">
        {/* Welcome Card */}
        <div className="bg-gradient-to-br from-secondary-800 to-secondary-900 rounded-2xl p-6 text-white shadow-lg">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
              <User className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold">{employer?.name || 'Employer'}</h2>
              <p className="text-secondary-200 text-sm">{employer?.company_name || 'Individual'}</p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="bg-white/10 rounded-xl p-3 text-center">
              <div className="text-2xl font-bold">{jobs.filter(j => j.status === 'open').length}</div>
              <div className="text-xs text-secondary-200 mt-1">Active Jobs</div>
            </div>
            <div className="bg-white/10 rounded-xl p-3 text-center">
              <div className="text-2xl font-bold">{applicants.size}</div>
              <div className="text-xs text-secondary-200 mt-1">Applicants</div>
            </div>
            <div className="bg-white/10 rounded-xl p-3 text-center">
              <div className="text-2xl font-bold">{jobs.length}</div>
              <div className="text-xs text-secondary-200 mt-1">Total Jobs</div>
            </div>
          </div>
        </div>

        {/* Upgrade CTA */}
        <div className="bg-gradient-to-r from-primary-500 to-orange-500 rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-white text-lg">Upgrade to MSME Plan</h3>
              <p className="text-primary-100 text-sm mt-1">Unlimited job posts. Priority support. Verified badge.</p>
            </div>
            <Zap className="w-10 h-10 text-white/50" />
          </div>
          <button className="mt-4 w-full py-3 bg-white text-primary-600 rounded-xl font-semibold min-h-[48px]">
            Upgrade Now
          </button>
        </div>

        {/* Active Jobs */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-gray-900">Your Active Jobs</h2>
            <Link
              to="/workers"
              className="text-primary-500 font-medium text-sm flex items-center gap-1"
            >
              Find Workers <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {loading ? (
            <div className="text-center py-8">
              <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin mx-auto" />
            </div>
          ) : jobs.length === 0 ? (
            <div className="text-center py-8">
              <Briefcase className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500 mb-4">No jobs posted yet</p>
              <Link
                to="/post-job"
                className="inline-flex items-center gap-2 px-6 py-3 bg-primary-500 text-white rounded-xl font-medium min-h-[48px]"
              >
                <PlusCircle className="w-4 h-4" />
                Post Your First Job
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {jobs.map(job => {
                const jobApplicants = applicants.get(job.id) || [];
                return (
                  <div key={job.id} className="border border-gray-200 rounded-xl overflow-hidden">
                    <div className="p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <h3 className="font-semibold text-gray-900">{job.title}</h3>
                            <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${getStatusColor(job.status)}`}>
                              {job.status.charAt(0).toUpperCase() + job.status.slice(1)}
                            </span>
                            {job.urgency === 'urgent' && (
                              <span className="bg-red-100 text-red-700 text-xs px-2 py-0.5 rounded-full font-medium flex items-center gap-1">
                                <Zap className="w-3 h-3" />
                                Urgent
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-2 mt-1 text-sm text-gray-500">
                            <span>{job.trade_required}</span>
                            <span>•</span>
                            <span className="flex items-center gap-1">
                              <MapPin className="w-4 h-4" />
                              {job.area || job.city}
                            </span>
                          </div>

                          <div className="flex items-center gap-4 mt-2 text-sm">
                            <span className="flex items-center gap-1">
                              <Clock className="w-4 h-4 text-gray-400" />
                              {job.duration}
                            </span>
                            <span className="font-bold text-primary-600">
                              {job.budget.toLocaleString('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 })}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {jobApplicants.length > 0 && (
                      <div className="bg-gray-50 p-4 border-t border-gray-200">
                        <div className="flex items-center gap-2 mb-3">
                          <Users className="w-4 h-4 text-gray-500" />
                          <span className="text-sm font-medium text-gray-700">
                            {jobApplicants.length} applicant{jobApplicants.length !== 1 ? 's' : ''}
                          </span>
                        </div>

                        <div className="space-y-2">
                          {jobApplicants.slice(0, 3).map(applicant => (
                            <div
                              key={applicant.id}
                              className="flex items-center justify-between bg-white rounded-lg p-3"
                            >
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center">
                                  <User className="w-5 h-5 text-primary-600" />
                                </div>
                                <div>
                                  <div className="flex items-center gap-2">
                                    <span className="font-medium text-gray-900">{applicant.name}</span>
                                    {applicant.verified && (
                                      <Shield className="w-4 h-4 text-green-600" />
                                    )}
                                  </div>
                                  <div className="flex items-center gap-2 text-xs text-gray-500">
                                    <span className="flex items-center gap-1">
                                      <Star className="w-3 h-3 text-yellow-500 fill-current" />
                                      {applicant.rating?.toFixed(1)}
                                    </span>
                                    <span>{applicant.jobs_completed} jobs</span>
                                    <span>{applicant.years_experience} yrs</span>
                                  </div>
                                </div>
                              </div>
                              <button className="px-3 py-1 bg-primary-500 text-white text-sm rounded-lg min-h-[36px]">
                                Contact
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-4">
          <Link
            to="/workers"
            className="bg-white rounded-xl p-4 shadow-sm flex items-center gap-3 hover:shadow-md transition-all"
          >
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <p className="font-semibold text-gray-900">Find Workers</p>
              <p className="text-xs text-gray-500">Browse all trades</p>
            </div>
            <ArrowRight className="w-4 h-4 text-gray-400 ml-auto" />
          </Link>

          <Link
            to="/post-job"
            className="bg-white rounded-xl p-4 shadow-sm flex items-center gap-3 hover:shadow-md transition-all"
          >
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <PlusCircle className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <p className="font-semibold text-gray-900">Post Job</p>
              <p className="text-xs text-gray-500">List new requirement</p>
            </div>
            <ArrowRight className="w-4 h-4 text-gray-400 ml-auto" />
          </Link>
        </div>
      </div>
    </div>
  );
}
