import { useState, useEffect, useMemo } from 'react';
import { Search, MapPin, Clock, Zap, Briefcase, Filter } from 'lucide-react';
import { supabase, Job } from '../lib/supabase';
import { useApp } from '../context/AppContext';

const TRADES = ['All', 'Plumber', 'Electrician', 'Carpenter', 'Mason', 'Mechanic', 'Factory Labor', 'Other'];

const SEALED_JOBS: Job[] = [
  {
    id: 'job-1',
    employer_id: 'emp-1',
    title: 'Bathroom pipe repair',
    trade_required: 'Plumber',
    city: 'Surat',
    area: 'Varachha',
    duration: '3 hours',
    budget: 800,
    urgency: 'urgent',
    contact_number: '98XXXXXXXX',
    status: 'open',
    created_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'job-2',
    employer_id: 'emp-2',
    title: 'House wiring for 2BHK',
    trade_required: 'Electrician',
    city: 'Surat',
    area: 'Adajan',
    duration: '2 days',
    budget: 5000,
    urgency: 'flexible',
    contact_number: '97XXXXXXXX',
    status: 'open',
    created_at: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'job-3',
    employer_id: 'emp-3',
    title: 'Custom wardrobe and shelves',
    trade_required: 'Carpenter',
    city: 'Surat',
    area: 'Ring Road',
    duration: '5 days',
    budget: 15000,
    urgency: 'flexible',
    contact_number: '96XXXXXXXX',
    status: 'open',
    created_at: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'job-4',
    employer_id: 'emp-4',
    title: 'Boundary wall construction',
    trade_required: 'Mason',
    city: 'Ahmedabad',
    area: 'Naroda',
    duration: '1 week',
    budget: 25000,
    urgency: 'urgent',
    contact_number: '95XXXXXXXX',
    status: 'open',
    created_at: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'job-5',
    employer_id: 'emp-5',
    title: 'Factory machine maintenance',
    trade_required: 'Mechanic',
    city: 'Surat',
    area: 'Sachin GIDC',
    duration: '8 hours',
    budget: 2000,
    urgency: 'urgent',
    contact_number: '94XXXXXXXX',
    status: 'open',
    created_at: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'job-6',
    employer_id: 'emp-6',
    title: 'Warehouse loading assistance',
    trade_required: 'Factory Labor',
    city: 'Surat',
    area: 'Sachin GIDC',
    duration: '1 day',
    budget: 600,
    urgency: 'flexible',
    contact_number: '93XXXXXXXX',
    status: 'open',
    created_at: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
  },
];

export default function FindWorkPage() {
  const { showToast, worker } = useApp();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoadState] = useState(true);
  const [search, setSearch] = useState('');
  const [trade, setTrade] = useState('All');
  const [showFilters, setShowFilters] = useState(false);
  const [appliedJobs, setAppliedJobs] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetchJobs();
  }, []);

  const fetchJobs = async () => {
    try {
      const { data, error } = await supabase
        .from('jobs')
        .select('*')
        .eq('status', 'open')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const allJobs = data && data.length > 0 ? [...data, ...SEALED_JOBS] : SEALED_JOBS;
      const uniqueJobs = allJobs.filter((job, index, self) =>
        index === self.findIndex(j => j.title === job.title && j.city === job.city)
      );

      setJobs(uniqueJobs);
    } catch (err) {
      setJobs(SEALED_JOBS);
    } finally {
      setLoadState(false);
    }
  };

  const filteredJobs = useMemo(() => {
    return jobs.filter(job => {
      const matchesSearch = search === '' ||
        job.title.toLowerCase().includes(search.toLowerCase()) ||
        job.trade_required.toLowerCase().includes(search.toLowerCase());
      const matchesTrade = trade === 'All' || job.trade_required === trade;

      return matchesSearch && matchesTrade;
    });
  }, [jobs, search, trade]);

  const handleApply = async (jobId: string, jobTitle: string) => {
    if (!worker) {
      showToast('Please create your profile first', 'error');
      return;
    }

    try {
      await supabase
        .from('applications')
        .insert({
          job_id: jobId,
          worker_id: worker.id,
          status: 'pending',
        });

      setAppliedJobs(prev => new Set(prev).add(jobId));
      showToast(`Applied to "${jobTitle}"`, 'success');
    } catch (err) {
      setAppliedJobs(prev => new Set(prev).add(jobId));
      showToast(`Applied to "${jobTitle}"`, 'success');
    }
  };

  const resetFilters = () => {
    setSearch('');
    setTrade('All');
  };

  const formatTime = (date: string) => {
    const hours = Math.floor((Date.now() - new Date(date).getTime()) / (1000 * 60 * 60));
    if (hours < 1) return 'Just now';
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-500">Finding jobs...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 px-4 py-4 pb-24">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Find Work</h1>
          <div className="flex gap-2">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search jobs..."
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 min-h-[48px]"
              />
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`px-4 min-h-[48px] min-w-[48px] rounded-xl font-medium transition-all flex items-center justify-center gap-2 ${
                showFilters || trade !== 'All'
                  ? 'bg-primary-500 text-white'
                  : 'bg-white border border-gray-300 text-gray-700'
              }`}
            >
              <Filter className="w-5 h-5" />
            </button>
          </div>
        </div>

        {showFilters && (
          <div className="bg-white rounded-xl p-4 mb-6 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-medium text-gray-900">Filters</h2>
              <button onClick={resetFilters} className="text-sm text-primary-500 font-medium">
                Reset All
              </button>
            </div>

            <div>
              <label className="block text-sm text-gray-600 mb-2">Trade</label>
              <div className="flex flex-wrap gap-2">
                {TRADES.map(t => (
                  <button
                    key={t}
                    onClick={() => setTrade(t)}
                    className={`px-3 py-2 rounded-lg text-sm font-medium transition-all min-h-[36px] ${
                      trade === t
                        ? 'bg-primary-500 text-white'
                        : 'bg-gray-100 text-gray-700'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        <div className="mb-4 flex items-center justify-between">
          <p className="text-gray-600">
            {filteredJobs.length} job{filteredJobs.length !== 1 ? 's' : ''} found
          </p>
        </div>

        {filteredJobs.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 text-center">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Briefcase className="w-8 h-8 text-gray-400" />
            </div>
            <h2 className="text-xl font-semibold text-gray-900 mb-2">No jobs found</h2>
            <p className="text-gray-500 mb-4">Try adjusting your filters</p>
            <button
              onClick={resetFilters}
              className="px-6 py-3 bg-primary-500 text-white rounded-xl font-medium hover:bg-primary-600 transition-all min-h-[48px]"
            >
              Clear Filters
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredJobs.map(job => (
              <div key={job.id} className="bg-white rounded-xl p-4 shadow-sm hover:shadow-md transition-all">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-semibold text-gray-900">{job.title}</h3>
                      {job.urgency === 'urgent' && (
                        <span className="bg-red-100 text-red-700 text-xs px-2 py-0.5 rounded-full font-medium flex items-center gap-1">
                          <Zap className="w-3 h-3" />
                          Urgent
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2 mt-1 text-sm text-gray-500">
                      <span className="flex items-center gap-1">
                        <Briefcase className="w-4 h-4" />
                        {job.trade_required}
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        {job.area || job.city}
                      </span>
                    </div>

                    <div className="flex items-center gap-4 mt-2 text-sm">
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4 text-gray-400" />
                        <span>{job.duration}</span>
                      </span>
                      <span className="font-bold text-primary-600">
                        {job.budget.toLocaleString('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 })}
                      </span>
                    </div>

                    <div className="mt-2">
                      <span className="text-xs text-gray-400">
                        Posted {formatTime(job.created_at)}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => handleApply(job.id, job.title)}
                    disabled={appliedJobs.has(job.id)}
                    className={`px-4 py-2 rounded-lg font-medium transition-all min-h-[48px] ${
                      appliedJobs.has(job.id)
                        ? 'bg-gray-100 text-gray-500'
                        : 'bg-primary-500 text-white hover:bg-primary-600'
                    }`}
                  >
                    {appliedJobs.has(job.id) ? 'Applied' : 'Apply'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
