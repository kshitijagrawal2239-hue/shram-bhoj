import { Link } from 'react-router-dom';
import { Hammer, Zap, Shield, Users, TrendingUp, Clock, CheckCircle, ArrowRight } from 'lucide-react';
import { useApp } from '../context/AppContext';

export default function LandingPage() {
  const { setUserType } = useApp();

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-500 to-primary-700">
      <header className="px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Hammer className="w-8 h-8 text-white" />
          <span className="text-xl font-bold text-white">Shram Bhoj</span>
        </div>
      </header>

      <main className="px-4 pt-8 pb-32 md:pt-16 md:pb-40">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-6xl font-extrabold text-white leading-tight mb-4">
              India's Manual Trades.
              <br />
              <span className="text-primary-100">Real-Time. Verified. Fair.</span>
            </h1>
            <p className="text-lg md:text-xl text-primary-100 max-w-2xl mx-auto">
              Connect with skilled workers in your area. No middlemen. Direct contact. Fair wages.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <Link
              to="/post-job"
              onClick={() => setUserType('employer')}
              className="flex items-center justify-center gap-2 px-8 py-4 bg-white text-primary-600 rounded-xl font-semibold text-lg shadow-lg hover:shadow-xl transition-all hover:scale-105 min-h-[48px]"
            >
              <Zap className="w-5 h-5" />
              Post a Job
            </Link>
            <Link
              to="/worker-onboarding"
              onClick={() => setUserType('worker')}
              className="flex items-center justify-center gap-2 px-8 py-4 bg-primary-900 text-white rounded-xl font-semibold text-lg shadow-lg hover:shadow-xl transition-all hover:scale-105 min-h-[48px]"
            >
              <Hammer className="w-5 h-5" />
              Find Work
            </Link>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mb-16">
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mb-4">
                <Clock className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">On-Demand Matching</h3>
              <p className="text-primary-100">
                Find verified workers in your area instantly. Real-time availability updates.
              </p>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mb-4">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Digital Identity</h3>
              <p className="text-primary-100">
                Shram Verified profiles with skills, ratings, and work history. Build your professional reputation.
              </p>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mb-4">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">No Middlemen</h3>
              <p className="text-primary-100">
                Keep 100% of your wages. Direct connection between workers and employers.
              </p>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 md:p-8 shadow-xl">
            <div className="grid md:grid-cols-3 gap-6 text-center">
              <div>
                <div className="text-3xl md:text-4xl font-extrabold text-primary-600 mb-1">450M+</div>
                <p className="text-gray-600">Workers in India</p>
              </div>
              <div>
                <div className="text-3xl md:text-4xl font-extrabold text-primary-600 mb-1">$455B</div>
                <p className="text-gray-600">Gig Economy Size</p>
              </div>
              <div>
                <div className="text-3xl md:text-4xl font-extrabold text-primary-600 mb-1">&lt;10%</div>
                <p className="text-gray-600">Have Digital Presence</p>
              </div>
            </div>
          </div>
        </div>
      </main>

      <div className="bg-secondary-900 px-4 py-8">
        <div className="max-w-5xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-xl font-bold text-white mb-4">For Workers</h3>
              <ul className="space-y-3">
                {[
                  'Create a verified professional profile',
                  'Get matched with local jobs',
                  'Build your reputation with ratings',
                  'No commission fees - keep your full wage',
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-2 text-gray-300">
                    <CheckCircle className="w-5 h-5 text-primary-500 flex-shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <Link
                to="/worker-onboarding"
                onClick={() => setUserType('worker')}
                className="inline-flex items-center gap-2 mt-6 text-primary-400 hover:text-primary-300 font-medium"
              >
                Create your profile <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            <div>
              <h3 className="text-xl font-bold text-white mb-4">For Employers</h3>
              <ul className="space-y-3">
                {[
                  'Post jobs in under 2 minutes',
                  'Access pre-verified workers',
                  'Filter by trade, location, availability',
                  'Direct contact - no middleman fees',
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-2 text-gray-300">
                    <CheckCircle className="w-5 h-5 text-primary-500 flex-shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <Link
                to="/post-job"
                onClick={() => setUserType('employer')}
                className="inline-flex items-center gap-2 mt-6 text-primary-400 hover:text-primary-300 font-medium"
              >
                Post your first job <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </div>

      <footer className="bg-secondary-900 border-t border-secondary-800 px-4 py-6">
        <div className="max-w-5xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Hammer className="w-5 h-5 text-gray-400" />
            <span className="text-gray-400 font-medium">Shram Bhoj</span>
          </div>
          <p className="text-gray-500 text-sm">
            Empowering India's workforce with digital identity and fair access to opportunities.
          </p>
        </div>
      </footer>
    </div>
  );
}
