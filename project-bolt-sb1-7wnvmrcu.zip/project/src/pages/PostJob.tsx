import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Briefcase, ArrowRight, CheckCircle, Zap, Clock, Users } from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  supabase,
  Worker,
  sanitizePhone,
  sanitizeText,
  validatePhone,
  validateName,
  validateBudget,
} from '../lib/supabase';

const TRADES = [
  'Plumber',
  'Electrician',
  'Carpenter',
  'Mason',
  'Mechanic',
  'Factory Labor',
  'Other',
];

const CITIES = ['Surat', 'Ahmedabad', 'Vadodara', 'Rajkot', 'Mumbai', 'Delhi'];

export default function PostJob() {
  const navigate = useNavigate();
  const { setEmployer, showToast } = useApp();
  const [step, setStep] = useState(1);
  const [loading, setLoadState] = useState(false);
  const [matchedWorkers, setMatchedWorkers] = useState<Worker[]>([]);
  const [formData, setFormData] = useState({
    title: '',
    employerName: '',
    phone: '',
    trade: '',
    city: '',
    area: '',
    duration: '',
    budget: '',
    urgency: 'flexible' as 'urgent' | 'flexible',
  });

  const updateForm = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    // Validate inputs
    if (!validateName(formData.employerName)) {
      showToast('Please enter a valid name (2-50 characters)', 'error');
      return;
    }

    const sanitizedPhone = sanitizePhone(formData.phone);
    if (!validatePhone(sanitizedPhone)) {
      showToast('Please enter a valid 10-digit mobile number', 'error');
      return;
    }

    const budget = parseInt(formData.budget);
    if (!validateBudget(budget)) {
      showToast('Please enter a valid budget (up to ₹1,00,00,000)', 'error');
      return;
    }

    setLoadState(true);
    try {
      let employerId = '';
      const { data: existingEmployer } = await supabase
        .from('employers')
        .select('id')
        .eq('phone', formData.phone)
        .maybeSingle();

      if (existingEmployer) {
        employerId = existingEmployer.id;
        setEmployer(existingEmployer);
      } else {
        const { data: newEmployer, error: employerError } = await supabase
          .from('employers')
          .insert({
            name: sanitizeText(formData.employerName),
            phone: sanitizedPhone,
            city: sanitizeText(formData.city),
          })
          .select()
          .maybeSingle();

        if (employerError) throw employerError;
        if (newEmployer) {
          employerId = newEmployer.id;
          setEmployer(newEmployer);
        }
      }

      const { error: jobError } = await supabase.from('jobs').insert({
        employer_id: employerId,
        title: sanitizeText(formData.title),
        trade_required: sanitizeText(formData.trade),
        city: sanitizeText(formData.city),
        area: formData.area ? sanitizeText(formData.area) : null,
        duration: sanitizeText(formData.duration),
        budget: budget,
        urgency: formData.urgency,
        contact_number: sanitizedPhone,
      });

      if (jobError) throw jobError;

      const { data: workers } = await supabase
        .from('workers')
        .select('*')
        .eq('trade', formData.trade)
        .eq('city', formData.city)
        .eq('availability', 'available')
        .limit(3);

      setMatchedWorkers(workers || []);
      setStep(3);
      showToast('Job posted successfully!', 'success');
    } catch (err) {
      showToast('Failed to post job. Please try again.', 'error');
    } finally {
      setLoadState(false);
    }
  };

  const seedFallbackWorkers = () => {
    return [
      {
        id: 'fallback-1',
        name: 'Ramesh Patel',
        trade: formData.trade,
        city: formData.city,
        area: 'Nearby',
        rating: 4.7,
        jobs_completed: 43,
        verified: true,
        years_experience: 8,
        phone: '98XXXXXXXX',
        skill_level: 4,
        availability: 'available',
        created_at: new Date().toISOString(),
      },
      {
        id: 'fallback-2',
        name: 'Sunil Kumar',
        trade: formData.trade,
        city: formData.city,
        area: 'Local',
        rating: 4.5,
        jobs_completed: 31,
        verified: true,
        years_experience: 5,
        phone: '97XXXXXXXX',
        skill_level: 4,
        availability: 'available',
        created_at: new Date().toISOString(),
      },
      {
        id: 'fallback-3',
        name: 'Mohammed Ansari',
        trade: formData.trade,
        city: formData.city,
        area: 'Metro',
        rating: 4.2,
        jobs_completed: 19,
        verified: false,
        years_experience: 12,
        phone: '96XXXXXXXX',
        skill_level: 5,
        availability: 'available',
        created_at: new Date().toISOString(),
      },
    ] as Worker[];
  };

  return (
    <div className="min-h-screen bg-gray-50 px-4 py-8">
      <div className="max-w-2xl mx-auto">
        {step === 1 && (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Briefcase className="w-8 h-8 text-primary-600" />
              </div>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Post a Job</h1>
              <p className="text-gray-500 mt-2">Find skilled workers in your area</p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-sm space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Job Title
                </label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={e => updateForm('title', e.target.value)}
                  placeholder="e.g., Need plumber for bathroom repair"
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 min-h-[48px]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Your Name
                </label>
                <input
                  type="text"
                  value={formData.employerName}
                  onChange={e => updateForm('employerName', e.target.value)}
                  placeholder="Enter your name"
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 min-h-[48px]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Contact Number
                </label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={e => updateForm('phone', e.target.value.replace(/\D/g, '').slice(0, 10))}
                  maxLength={10}
                  placeholder="10-digit mobile number"
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 min-h-[48px]"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Trade Required
                  </label>
                  <select
                    value={formData.trade}
                    onChange={e => updateForm('trade', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 min-h-[48px] bg-white"
                  >
                    <option value="">Select trade</option>
                    {TRADES.map(trade => (
                      <option key={trade} value={trade}>{trade}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    City
                  </label>
                  <select
                    value={formData.city}
                    onChange={e => updateForm('city', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 min-h-[48px] bg-white"
                  >
                    <option value="">Select city</option>
                    {CITIES.map(city => (
                      <option key={city} value={city}>{city}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Area/Locality
                </label>
                <input
                  type="text"
                  value={formData.area}
                  onChange={e => updateForm('area', e.target.value)}
                  placeholder="e.g., Varachha, Adajan"
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 min-h-[48px]"
                />
              </div>
            </div>

            <button
              onClick={() => setStep(2)}
              disabled={!formData.title || !formData.trade || !formData.city || !formData.phone}
              className="w-full py-4 bg-primary-500 text-white rounded-xl font-semibold hover:bg-primary-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 min-h-[48px]"
            >
              Continue
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-primary-600" />
              </div>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Job Details</h1>
              <p className="text-gray-500 mt-2">Specify duration and budget</p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-sm space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Duration
                </label>
                <input
                  type="text"
                  value={formData.duration}
                  onChange={e => updateForm('duration', e.target.value)}
                  placeholder="e.g., 2 days, 4 hours, 1 week"
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 min-h-[48px]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Budget (₹)
                </label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-medium">₹</span>
                  <input
                    type="number"
                    value={formData.budget}
                    onChange={e => updateForm('budget', e.target.value.replace(/[^0-9]/g, '').slice(0, 8))}
                    placeholder="e.g., 5000"
                    min="1"
                    max="10000000"
                    className="w-full px-4 py-3 pl-9 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 min-h-[48px]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Urgency
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => updateForm('urgency', 'urgent')}
                    className={`py-3 rounded-xl font-medium transition-all min-h-[48px] flex items-center justify-center gap-2 ${
                      formData.urgency === 'urgent'
                        ? 'bg-red-500 text-white'
                        : 'bg-white border border-gray-300 text-gray-700'
                    }`}
                  >
                    <Zap className="w-5 h-5" />
                    Urgent
                  </button>
                  <button
                    onClick={() => updateForm('urgency', 'flexible')}
                    className={`py-3 rounded-xl font-medium transition-all min-h-[48px] flex items-center justify-center gap-2 ${
                      formData.urgency === 'flexible'
                        ? 'bg-primary-500 text-white'
                        : 'bg-white border border-gray-300 text-gray-700'
                    }`}
                  >
                    <Clock className="w-5 h-5" />
                    Flexible
                  </button>
                </div>
              </div>
            </div>

            <button
              onClick={handleSubmit}
              disabled={loading || !formData.duration || !formData.budget}
              className="w-full py-4 bg-primary-500 text-white rounded-xl font-semibold hover:bg-primary-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 min-h-[48px]"
            >
              {loading ? 'Posting...' : 'Post Job'}
            </button>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Job Posted!</h1>
              <p className="text-gray-500 mt-2">Matching workers nearby...</p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <h2 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <Users className="w-5 h-5 text-primary-500" />
                {matchedWorkers.length > 0
                  ? `${matchedWorkers.length} workers matched`
                  : 'Sample workers available'}
              </h2>

              <div className="space-y-3">
                {(matchedWorkers.length > 0 ? matchedWorkers : seedFallbackWorkers()).map(worker => (
                  <div
                    key={worker.id}
                    className="bg-gray-50 rounded-xl p-4 hover:bg-gray-100 transition-all"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-medium text-gray-900">{worker.name}</h3>
                          {worker.verified && (
                            <span className="bg-green-100 text-green-700 text-xs px-2 py-0.5 rounded-full font-medium">
                              Verified
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-gray-500">{worker.trade} • {worker.area || worker.city}</p>
                        <div className="flex items-center gap-3 mt-2 text-sm">
                          <span className="text-gray-600">
                            ⭐ {worker.rating?.toFixed(1) || 'New'}
                          </span>
                          <span className="text-gray-600">
                            {worker.jobs_completed} jobs
                          </span>
                          <span className="text-gray-600">
                            {worker.years_experience} yrs exp
                          </span>
                        </div>
                      </div>
                      <button
                        onClick={() => showToast('Request sent to ' + worker.name, 'success')}
                        className="px-4 py-2 bg-primary-500 text-white text-sm rounded-lg hover:bg-primary-600 transition-all min-h-[36px]"
                      >
                        Contact
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => navigate('/workers')}
                className="py-3 bg-white border border-gray-300 rounded-xl font-medium hover:bg-gray-50 transition-all min-h-[48px]"
              >
                Find More Workers
              </button>
              <button
                onClick={() => navigate('/dashboard')}
                className="py-3 bg-primary-500 text-white rounded-xl font-medium hover:bg-primary-600 transition-all min-h-[48px]"
              >
                Go to Dashboard
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
