import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { User, Star, Briefcase, TrendingUp, ArrowRight, Shield, MapPin, Clock } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { supabase, Job } from '../lib/supabase';

const MATCHING_JOBS: Job[] = [
  {
    id: 'match-1',
    employer_id: 'emp-1',
    title: 'Emergency pipe repair',
    trade_required: 'Plumber',
    city: 'Surat',
    area: 'Varachha',
    duration: '2 hours',
    budget: 500,
    urgency: 'urgent',
    contact_number: '98XXXXXXXX',
    status: 'open',
    created_at: new Date().toISOString(),
  },
  {
    id: 'match-2',
    employer_id: 'emp-2',
    title: 'Bathroom renovation',
    trade_required: 'Plumber',
    city: 'Surat',
    area: 'Adajan',
    duration: '3 days',
    budget: 8000,
    urgency: 'flexible',
    contact_number: '97XXXXXXXX',
    status: 'open',
    created_at: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'match-3',
    employer_id: 'emp-3',
    title: 'Kitchen sink installation',
    trade_required: 'Plumber',
    city: 'Surat',
    area: 'Ring Road',
    duration: '4 hours',
    budget: 1200,
    urgency: 'flexible',
    contact_number: '96XXXXXXXX',
    status: 'open',
    created_at: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
  },
];

export default function WorkerDashboard() {
  const { worker } = useApp();
  const [matchingJobs, setMatchingJobs] = useState<Job[]>([]);
  const [loading, setLoadState] = useState(true);
  const [appliedJobs, setAppliedJobs] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetchMatchingJobs();
  }, [worker]);

  const fetchMatchingJobs = async () => {
    if (!worker) return;

    try {
      const { data, error } = await supabase
        .from('jobs')
        .select('*')
        .eq('status', 'open')
        .eq('trade_required', worker.trade)
        .eq('city', worker.city)
        .limit(5);

      if (error) throw error;

      const jobs = data && data.length > 0 ? data : MATCHING_JOBS.filter(j => j.trade_required === worker.trade);
      setMatchingJobs(jobs.length > 0 ? jobs : MATCHING_JOBS.slice(0, 3));
    } catch (err) {
      setMatchingJobs(MATCHING_JOBS.slice(0, 3));
    } finally {
      setLoadState(false);
    }
  };

  const handleApply = async (jobId: string, jobTitle: string) => {
    if (!worker) return;

    try {
      await supabase
        .from('applications')
        .insert({
          job_id: jobId,
          worker_id: worker.id,
          status: 'pending',
        });

      setAppliedJobs(prev => new Set(prev).add(jobId));
    } catch (err) {
      setAppliedJobs(prev => new Set(prev).add(jobId));
    }
  };

  if (!worker) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
        <div className="text-center">
          <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <User className="w-8 h-8 text-primary-600" />
          </div>
          <h1 className="text-xl font-bold text-gray-900 mb-2">Create Your Profile</h1>
          <p className="text-gray-500 mb-6">Set up your worker profile to access your dashboard</p>
          <Link
            to="/worker-onboarding"
            className="inline-flex items-center gap-2 px-6 py-3 bg-primary-500 text-white rounded-xl font-medium hover:bg-primary-600 transition-all min-h-[48px]"
          >
            Create Profile <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      <header className="px-4 py-4 bg-white border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold text-gray-900">Dashboard</h1>
        </div>
      </header>

      <div className="px-4 py-6 max-w-4xl mx-auto space-y-6">
        {/* Profile Card */}
        <div className="bg-gradient-to-br from-primary-500 to-primary-700 rounded-2xl p-6 text-white shadow-lg">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                <User className="w-8 h-8" />
              </div>
              <div>
                <h2 className="text-xl font-bold">{worker.name}</h2>
                <p className="text-primary-100">{worker.trade}</p>
                <p className="text-sm text-primary-200 flex items-center gap-1 mt-1">
                  <MapPin className="w-4 h-4" />
                  {worker.city}
                </p>
              </div>
            </div>
            {worker.verified && (
              <div className="bg-white/20 rounded-lg px-3 py-1 flex items-center gap-1">
                <Shield className="w-4 h-4" />
                <span className="text-sm font-medium">Verified</span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-3 gap-3 mb-4">
            <div className="bg-white/20 rounded-xl p-3 text-center">
              <div className="text-2xl font-bold flex items-center justify-center gap-1">
                <Star className="w-5 h-5 fill-current" />
                {worker.rating?.toFixed(1) || 'New'}
              </div>
              <div className="text-xs text-primary-100 mt-1">Rating</div>
            </div>
            <div className="bg-white/20 rounded-xl p-3 text-center">
              <div className="text-2xl font-bold">{worker.jobs_completed}</div>
              <div className="text-xs text-primary-100 mt-1">Jobs Done</div>
            </div>
            <div className="bg-white/20 rounded-xl p-3 text-center">
              <div className="text-2xl font-bold">{worker.years_experience}</div>
              <div className="text-xs text-primary-100 mt-1">Years Exp</div>
            </div>
          </div>

          <div className="bg-white/20 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-primary-100">Total Earnings</p>
                <p className="text-2xl font-bold mt-1">
                  {worker.jobs_completed * 2000}
                </p>
              </div>
              <TrendingUp className="w-8 h-8 opacity-50" />
            </div>
          </div>
        </div>

        {/* Matching Jobs */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-gray-900">Jobs Matching You</h2>
            <Link
              to="/find-work"
              className="text-primary-500 font-medium text-sm flex items-center gap-1"
            >
              View All <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {loading ? (
            <div className="text-center py-8">
              <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin mx-auto" />
            </div>
          ) : matchingJobs.length === 0 ? (
            <div className="text-center py-8">
              <Briefcase className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">No matching jobs right now</p>
            </div>
          ) : (
            <div className="space-y-3">
              {matchingJobs.map(job => (
                <div key={job.id} className="bg-gray-50 rounded-xl p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-gray-900">{job.title}</h3>
                      <div className="flex items-center gap-2 mt-1 text-sm text-gray-500">
                        <span>{job.area || job.city}</span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {job.duration}
                        </span>
                      </div>
                      <p className="text-lg font-bold text-primary-600 mt-2">
                        {job.budget.toLocaleString('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 })}
                      </p>
                    </div>
                    <button
                      onClick={() => handleApply(job.id, job.title)}
                      disabled={appliedJobs.has(job.id)}
                      className={`px-4 py-2 rounded-lg font-medium transition-all min-h-[48px] ${
                        appliedJobs.has(job.id)
                          ? 'bg-gray-200 text-gray-500'
                          : 'bg-primary-500 text-white hover:bg-primary-600'
                      }`}
                    >
                      {appliedJobs.has(job.id) ? 'Applied' : 'Apply'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white rounded-xl p-4 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <Briefcase className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{matchingJobs.length}</p>
                <p className="text-sm text-gray-500">Open Jobs</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-4 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{worker.skill_level}/5</p>
                <p className="text-sm text-gray-500">Skill Level</p>
              </div>
            </div>
          </div>
        </div>

        {/* Availability Toggle */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <h2 className="text-lg font-bold text-gray-900 mb-4">Availability Status</h2>
          <div className="flex gap-3">
            <button className="flex-1 py-3 bg-primary-500 text-white rounded-xl font-medium min-h-[48px]">
              Available
            </button>
            <button className="flex-1 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium min-h-[48px]">
              Busy
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
