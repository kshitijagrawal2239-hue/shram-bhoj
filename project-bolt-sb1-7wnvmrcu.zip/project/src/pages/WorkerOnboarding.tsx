import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Hammer, ArrowRight, ArrowLeft, CheckCircle, User, Star, Shield } from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  supabase,
  sanitizePhone,
  sanitizeText,
  sanitizeAadhaar,
  validatePhone,
  validateName,
  validateYears,
  validateSkillLevel,
  validateAadhaar,
} from '../lib/supabase';

const TRADES = [
  'Plumber',
  'Electrician',
  'Carpenter',
  'Mason',
  'Mechanic',
  'Factory Labor',
  'Other',
];

const CITIES = ['Surat', 'Ahmedabad', 'Vadodara', 'Rajkot', 'Mumbai', 'Delhi'];

export default function WorkerOnboarding() {
  const navigate = useNavigate();
  const { setWorker, showToast } = useApp();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    city: '',
    trade: '',
    years: '',
    skillLevel: 3,
    aadhaar: '',
  });

  const updateForm = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    // Validate inputs
    if (!validateName(formData.name)) {
      showToast('Please enter a valid name (2-50 characters)', 'error');
      return;
    }

    const sanitizedPhone = sanitizePhone(formData.phone);
    if (!validatePhone(sanitizedPhone)) {
      showToast('Please enter a valid 10-digit mobile number', 'error');
      return;
    }

    const years = parseInt(formData.years);
    if (!validateYears(years)) {
      showToast('Please enter valid years of experience (0-50)', 'error');
      return;
    }

    if (!validateSkillLevel(formData.skillLevel)) {
      showToast('Skill level must be between 1 and 5', 'error');
      return;
    }

    let sanitizedAadhaar = null;
    if (formData.aadhaar) {
      sanitizedAadhaar = sanitizeAadhaar(formData.aadhaar);
      if (!validateAadhaar(sanitizedAadhaar)) {
        showToast('Please enter a valid 12-digit Aadhaar number', 'error');
        return;
      }
    }

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('workers')
        .insert({
          name: sanitizeText(formData.name),
          phone: sanitizedPhone,
          city: sanitizeText(formData.city),
          trade: sanitizeText(formData.trade),
          years_experience: years,
          skill_level: formData.skillLevel,
          aadhaar_number: sanitizedAadhaar,
          verified: !!sanitizedAadhaar,
          availability: 'available',
        })
        .select()
        .single();

      if (error) throw error;

      setWorker(data);
      showToast('Profile created successfully!', 'success');
      setTimeout(() => navigate('/dashboard'), 1500);
    } catch (err) {
      showToast('Failed to create profile. Please try again.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const renderStepIndicator = () => (
    <div className="flex items-center justify-center gap-2 mb-8">
      {[1, 2, 3, 4].map(i => (
        <div
          key={i}
          className={`w-3 h-3 rounded-full transition-all ${
            i <= step ? 'bg-primary-500' : 'bg-gray-300'
          }`}
        />
      ))}
    </div>
  );

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <User className="w-8 h-8 text-primary-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900">Basic Info</h2>
              <p className="text-gray-500 mt-2">Tell us about yourself</p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Full Name
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={e => updateForm('name', e.target.value)}
                  placeholder="Enter your full name"
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 min-h-[48px]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={e => updateForm('phone', e.target.value.replace(/\D/g, '').slice(0, 10))}
                  maxLength={10}
                  placeholder="10-digit mobile number"
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 min-h-[48px]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  City
                </label>
                <select
                  value={formData.city}
                  onChange={e => updateForm('city', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 min-h-[48px] bg-white"
                >
                  <option value="">Select your city</option>
                  {CITIES.map(city => (
                    <option key={city} value={city}>{city}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Trade Category
                </label>
                <select
                  value={formData.trade}
                  onChange={e => updateForm('trade', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 min-h-[48px] bg-white"
                >
                  <option value="">Select your trade</option>
                  {TRADES.map(trade => (
                    <option key={trade} value={trade}>{trade}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Hammer className="w-8 h-8 text-primary-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900">Skills & Experience</h2>
              <p className="text-gray-500 mt-2">Showcase your expertise</p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Years of Experience
                </label>
                <input
                  type="number"
                  value={formData.years}
                  onChange={e => updateForm('years', e.target.value.replace(/[^0-9]/g, '').slice(0, 2))}
                  placeholder="How many years in this trade?"
                  min="0"
                  max="50"
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 min-h-[48px]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Skill Level
                </label>
                <div className="bg-gray-50 rounded-xl p-4">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm text-gray-600">Rate your skill level</span>
                    <Star className="w-5 h-5 text-yellow-500 fill-current" />
                  </div>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map(level => (
                      <button
                        key={level}
                        onClick={() => updateForm('skillLevel', level)}
                        className={`flex-1 py-3 rounded-lg font-medium transition-all min-h-[48px] ${
                          formData.skillLevel >= level
                            ? 'bg-primary-500 text-white'
                            : 'bg-white border border-gray-300 text-gray-700'
                        }`}
                      >
                        {level}
                      </button>
                    ))}
                  </div>
                  <div className="flex justify-between mt-2 text-xs text-gray-500">
                    <span>Beginner</span>
                    <span>Expert</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-primary-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900">Verification (Optional)</h2>
              <p className="text-gray-500 mt-2">Add Aadhaar to get verified badge</p>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
              <p className="text-sm text-blue-800">
                <strong>Why verify?</strong> Verified workers get 3x more job requests and build trust with employers.
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Aadhaar Number (Optional)
              </label>
              <input
                type="text"
                value={formData.aadhaar}
                onChange={e => updateForm('aadhaar', e.target.value.replace(/\D/g, '').slice(0, 12))}
                placeholder="12-digit Aadhaar number"
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 min-h-[48px]"
              />
              <p className="text-xs text-gray-500 mt-2">
                Your data is secure and never shared without consent.
              </p>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900">Your Profile Card</h2>
              <p className="text-gray-500 mt-2">Preview your Shram Profile</p>
            </div>

            <div className="bg-gradient-to-br from-primary-500 to-primary-700 rounded-2xl p-6 text-white shadow-xl">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-xl font-bold">{formData.name || 'Your Name'}</h3>
                  <p className="text-primary-100">{formData.trade || 'Trade'}</p>
                  <p className="text-sm text-primary-200">{formData.city || 'City'}</p>
                </div>
                {formData.aadhaar && (
                  <div className="bg-white/20 rounded-lg px-3 py-1 flex items-center gap-1">
                    <Shield className="w-4 h-4" />
                    <span className="text-xs font-medium">Verified</span>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-3 gap-4 mb-4">
                <div className="bg-white/20 rounded-xl p-3 text-center">
                  <div className="text-2xl font-bold">{formData.years || 0}</div>
                  <div className="text-xs text-primary-100">Years Exp</div>
                </div>
                <div className="bg-white/20 rounded-xl p-3 text-center">
                  <div className="text-2xl font-bold flex items-center justify-center gap-1">
                    <Star className="w-5 h-5 fill-current" />
                    {formData.skillLevel}
                  </div>
                  <div className="text-xs text-primary-100">Skill Level</div>
                </div>
                <div className="bg-white/20 rounded-xl p-3 text-center">
                  <div className="text-2xl font-bold">0</div>
                  <div className="text-xs text-primary-100">Jobs Done</div>
                </div>
              </div>

              <div className="bg-white/20 rounded-xl p-3">
                <p className="text-sm text-primary-100 mb-1">Phone</p>
                <p className="font-medium">{formData.phone || 'Not provided'}</p>
              </div>
            </div>

            <button
              onClick={handleSubmit}
              disabled={loading}
              className="w-full py-4 bg-primary-500 text-white rounded-xl font-semibold hover:bg-primary-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed min-h-[48px]"
            >
              {loading ? 'Creating Profile...' : 'Create My Profile'}
            </button>
          </div>
        );

      default:
        return null;
    }
  };

  const canProceed = () => {
    switch (step) {
      case 1:
        return formData.name && formData.phone && formData.city && formData.trade;
      case 2:
        return formData.years && formData.skillLevel;
      default:
        return true;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 px-4 py-8">
      <div className="max-w-md mx-auto">
        <button
          onClick={() => (step > 1 ? setStep(step - 1) : navigate('/'))}
          className="flex items-center gap-2 text-gray-600 mb-6 min-h-[48px]"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back</span>
        </button>

        {renderStepIndicator()}
        {renderStep()}

        {step < 4 && (
          <button
            onClick={() => setStep(step + 1)}
            disabled={!canProceed()}
            className="w-full mt-6 py-4 bg-primary-500 text-white rounded-xl font-semibold hover:bg-primary-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 min-h-[48px]"
          >
            Continue
            <ArrowRight className="w-5 h-5" />
          </button>
        )}
      </div>
    </div>
  );
}
