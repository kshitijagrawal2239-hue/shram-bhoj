import { useState, useEffect, useMemo } from 'react';
import { Search, MapPin, Star, Shield, Filter, X } from 'lucide-react';
import { supabase, Worker } from '../lib/supabase';
import { useApp } from '../context/AppContext';

const TRADES = ['All', 'Plumber', 'Electrician', 'Carpenter', 'Mason', 'Mechanic', 'Factory Labor', 'Other'];
const CITIES = ['All', 'Surat', 'Ahmedabad', 'Vadodara', 'Rajkot', 'Mumbai', 'Delhi'];

const SEALED_WORKERS: Worker[] = [
  {
    id: '1',
    name: 'Ramesh Patel',
    trade: 'Plumber',
    city: 'Surat',
    area: 'Varachha',
    rating: 4.7,
    jobs_completed: 43,
    verified: true,
    years_experience: 8,
    phone: '98XXXXXXXX',
    skill_level: 4,
    availability: 'available',
    created_at: new Date().toISOString(),
  },
  {
    id: '2',
    name: 'Sunil Kumar',
    trade: 'Electrician',
    city: 'Surat',
    area: 'Adajan',
    rating: 4.5,
    jobs_completed: 31,
    verified: true,
    years_experience: 5,
    phone: '97XXXXXXXX',
    skill_level: 4,
    availability: 'available',
    created_at: new Date().toISOString(),
  },
  {
    id: '3',
    name: 'Mohammed Ansari',
    trade: 'Carpenter',
    city: 'Surat',
    area: 'Ring Road',
    rating: 4.2,
    jobs_completed: 19,
    verified: false,
    years_experience: 12,
    phone: '96XXXXXXXX',
    skill_level: 5,
    availability: 'available',
    created_at: new Date().toISOString(),
  },
  {
    id: '4',
    name: 'Deepak Yadav',
    trade: 'Mason',
    city: 'Surat',
    area: 'Katargam',
    rating: 4.8,
    jobs_completed: 67,
    verified: true,
    years_experience: 15,
    phone: '95XXXXXXXX',
    skill_level: 5,
    availability: 'available',
    created_at: new Date().toISOString(),
  },
  {
    id: '5',
    name: 'Pradeep Nair',
    trade: 'Mechanic',
    city: 'Ahmedabad',
    area: 'Naroda',
    rating: 4.0,
    jobs_completed: 22,
    verified: true,
    years_experience: 7,
    phone: '94XXXXXXXX',
    skill_level: 4,
    availability: 'busy',
    created_at: new Date().toISOString(),
  },
  {
    id: '6',
    name: 'Arjun Bisht',
    trade: 'Factory Labor',
    city: 'Surat',
    area: 'Sachin GIDC',
    rating: 3.9,
    jobs_completed: 11,
    verified: false,
    years_experience: 3,
    phone: '93XXXXXXXX',
    skill_level: 3,
    availability: 'available',
    created_at: new Date().toISOString(),
  },
];

export default function WorkersPage() {
  const { showToast } = useApp();
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [loading, setLoadState] = useState(true);
  const [search, setSearch] = useState('');
  const [trade, setTrade] = useState('All');
  const [city, setCity] = useState('All');
  const [verifiedOnly, setVerifiedOnly] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [contactedWorkers, setContactedWorkers] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetchWorkers();
  }, []);

  const fetchWorkers = async () => {
    try {
      const { data, error } = await supabase
        .from('workers')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const allWorkers = data && data.length > 0 ? [...data, ...SEALED_WORKERS] : SEALED_WORKERS;
      const uniqueWorkers = allWorkers.filter((worker, index, self) =>
        index === self.findIndex(w => w.name === worker.name && w.city === worker.city)
      );

      setWorkers(uniqueWorkers);
    } catch (err) {
      setWorkers(SEALED_WORKERS);
    } finally {
      setLoadState(false);
    }
  };

  const filteredWorkers = useMemo(() => {
    return workers.filter(worker => {
      const matchesSearch = search === '' ||
        worker.name.toLowerCase().includes(search.toLowerCase()) ||
        worker.trade.toLowerCase().includes(search.toLowerCase());
      const matchesTrade = trade === 'All' || worker.trade === trade;
      const matchesCity = city === 'All' || worker.city === city;
      const matchesVerified = !verifiedOnly || worker.verified;

      return matchesSearch && matchesTrade && matchesCity && matchesVerified;
    });
  }, [workers, search, trade, city, verifiedOnly]);

  const handleContact = (workerId: string, workerName: string) => {
    setContactedWorkers(prev => new Set(prev).add(workerId));
    showToast(`Request sent to ${workerName}`, 'success');
  };

  const resetFilters = () => {
    setSearch('');
    setTrade('All');
    setCity('All');
    setVerifiedOnly(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-500">Finding workers...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 px-4 py-4 pb-24">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Find Workers</h1>
          <div className="flex gap-2">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search by name or trade..."
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 min-h-[48px]"
              />
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`px-4 min-h-[48px] min-w-[48px] rounded-xl font-medium transition-all flex items-center justify-center gap-2 ${
                showFilters || trade !== 'All' || city !== 'All' || verifiedOnly
                  ? 'bg-primary-500 text-white'
                  : 'bg-white border border-gray-300 text-gray-700'
              }`}
            >
              <Filter className="w-5 h-5" />
            </button>
          </div>
        </div>

        {showFilters && (
          <div className="bg-white rounded-xl p-4 mb-6 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-medium text-gray-900">Filters</h2>
              <button onClick={resetFilters} className="text-sm text-primary-500 font-medium">
                Reset All
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-600 mb-2">Trade</label>
                <div className="flex flex-wrap gap-2">
                  {TRADES.map(t => (
                    <button
                      key={t}
                      onClick={() => setTrade(t)}
                      className={`px-3 py-2 rounded-lg text-sm font-medium transition-all min-h-[36px] ${
                        trade === t
                          ? 'bg-primary-500 text-white'
                          : 'bg-gray-100 text-gray-700'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm text-gray-600 mb-2">City</label>
                <div className="flex flex-wrap gap-2">
                  {CITIES.map(c => (
                    <button
                      key={c}
                      onClick={() => setCity(c)}
                      className={`px-3 py-2 rounded-lg text-sm font-medium transition-all min-h-[36px] ${
                        city === c
                          ? 'bg-primary-500 text-white'
                          : 'bg-gray-100 text-gray-700'
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => setVerifiedOnly(!verifiedOnly)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all min-h-[36px] ${
                    verifiedOnly
                      ? 'bg-green-500 text-white'
                      : 'bg-gray-100 text-gray-700'
                  }`}
                >
                  <Shield className="w-4 h-4" />
                  Verified Only
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="mb-4 flex items-center justify-between">
          <p className="text-gray-600">
            {filteredWorkers.length} worker{filteredWorkers.length !== 1 ? 's' : ''} found
          </p>
        </div>

        {filteredWorkers.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 text-center">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-gray-400" />
            </div>
            <h2 className="text-xl font-semibold text-gray-900 mb-2">No workers found</h2>
            <p className="text-gray-500 mb-4">Try adjusting your filters</p>
            <button
              onClick={resetFilters}
              className="px-6 py-3 bg-primary-500 text-white rounded-xl font-medium hover:bg-primary-600 transition-all min-h-[48px]"
            >
              Clear Filters
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredWorkers.map(worker => (
              <div key={worker.id} className="bg-white rounded-xl p-4 shadow-sm hover:shadow-md transition-all">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-semibold text-gray-900">{worker.name}</h3>
                      {worker.verified && (
                        <span className="bg-green-100 text-green-700 text-xs px-2 py-0.5 rounded-full font-medium flex items-center gap-1">
                          <Shield className="w-3 h-3" />
                          Verified
                        </span>
                      )}
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                        worker.availability === 'available'
                          ? 'bg-blue-100 text-blue-700'
                          : 'bg-gray-100 text-gray-600'
                      }`}>
                        {worker.availability === 'available' ? 'Available' : 'Busy'}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 mt-1 text-sm text-gray-500">
                      <span>{worker.trade}</span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        {worker.area || worker.city}
                      </span>
                    </div>

                    <div className="flex items-center gap-4 mt-2 text-sm">
                      <span className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-yellow-500 fill-current" />
                        <span className="font-medium">{worker.rating?.toFixed(1) || 'New'}</span>
                      </span>
                      <span className="text-gray-600">{worker.jobs_completed} jobs</span>
                      <span className="text-gray-600">{worker.years_experience} yrs</span>
                    </div>
                  </div>

                  <button
                    onClick={() => handleContact(worker.id, worker.name)}
                    disabled={contactedWorkers.has(worker.id)}
                    className={`px-4 py-2 rounded-lg font-medium transition-all min-h-[48px] ${
                      contactedWorkers.has(worker.id)
                        ? 'bg-gray-100 text-gray-500'
                        : 'bg-primary-500 text-white hover:bg-primary-600'
                    }`}
                  >
                    {contactedWorkers.has(worker.id) ? 'Request Sent' : 'Contact'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
