/*
  # Initial Schema for Shram Bhoj

  1. New Tables
    - `workers`
      - `id` (uuid, primary key)
      - `name` (text)
      - `phone` (text, unique)
      - `city` (text)
      - `area` (text)
      - `trade` (text)
      - `years_experience` (integer)
      - `skill_level` (integer, 1-5)
      - `rating` (decimal, default 0)
      - `jobs_completed` (integer, default 0)
      - `verified` (boolean, default false)
      - `aadhaar_number` (text, nullable)
      - `availability` (text, default 'available')
      - `created_at` (timestamp)
    - `employers`
      - `id` (uuid, primary key)
      - `name` (text)
      - `phone` (text, unique)
      - `company_name` (text, nullable)
      - `city` (text)
      - `created_at` (timestamp)
    - `jobs`
      - `id` (uuid, primary key)
      - `employer_id` (uuid, foreign key to employers)
      - `title` (text)
      - `trade_required` (text)
      - `city` (text)
      - `area` (text)
      - `duration` (text)
      - `budget` (integer)
      - `urgency` (text, default 'flexible')
      - `contact_number` (text)
      - `status` (text, default 'open')
      - `created_at` (timestamp)
    - `applications`
      - `id` (uuid, primary key)
      - `job_id` (uuid, foreign key to jobs)
      - `worker_id` (uuid, foreign key to workers)
      - `status` (text, default 'pending')
      - `created_at` (timestamp)
  
  2. Security
    - Enable RLS on all tables
    - Public read access for workers and open jobs
    - Authenticated users can manage their own data
*/

-- Workers table
CREATE TABLE IF NOT EXISTS workers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  phone text UNIQUE NOT NULL,
  city text NOT NULL,
  area text,
  trade text NOT NULL,
  years_experience integer DEFAULT 0,
  skill_level integer DEFAULT 3 CHECK (skill_level >= 1 AND skill_level <= 5),
  rating decimal(3,2) DEFAULT 0.00 CHECK (rating >= 0 AND rating <= 5),
  jobs_completed integer DEFAULT 0,
  verified boolean DEFAULT false,
  aadhaar_number text,
  availability text DEFAULT 'available' CHECK (availability IN ('available', 'busy', 'unavailable')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Employers table
CREATE TABLE IF NOT EXISTS employers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  phone text UNIQUE NOT NULL,
  company_name text,
  city text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Jobs table
CREATE TABLE IF NOT EXISTS jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employer_id uuid REFERENCES employers(id) ON DELETE CASCADE,
  title text NOT NULL,
  trade_required text NOT NULL,
  city text NOT NULL,
  area text,
  duration text NOT NULL,
  budget integer NOT NULL,
  urgency text DEFAULT 'flexible' CHECK (urgency IN ('urgent', 'flexible')),
  contact_number text NOT NULL,
  status text DEFAULT 'open' CHECK (status IN ('open', 'filled', 'closed', 'cancelled')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Applications table
CREATE TABLE IF NOT EXISTS applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid REFERENCES jobs(id) ON DELETE CASCADE,
  worker_id uuid REFERENCES workers(id) ON DELETE CASCADE,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected', 'withdrawn')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(job_id, worker_id)
);

-- Enable RLS on all tables
ALTER TABLE workers ENABLE ROW LEVEL SECURITY;
ALTER TABLE employers ENABLE ROW LEVEL SECURITY;
ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE applications ENABLE ROW LEVEL SECURITY;

-- Workers policies (public read for marketplace discovery)
CREATE POLICY "Workers are publicly readable"
  ON workers FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can create worker profile"
  ON workers FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Workers can update own profile"
  ON workers FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

-- Employers policies
CREATE POLICY "Employers are publicly readable"
  ON employers FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can create employer profile"
  ON employers FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Employers can update own profile"
  ON employers FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

-- Jobs policies (public read for discovery)
CREATE POLICY "Open jobs are publicly readable"
  ON jobs FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can create jobs"
  ON jobs FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Jobs can be updated"
  ON jobs FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

-- Applications policies
CREATE POLICY "Applications are readable"
  ON applications FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can create applications"
  ON applications FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Applications can be updated"
  ON applications FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_workers_trade ON workers(trade);
CREATE INDEX IF NOT EXISTS idx_workers_city ON workers(city);
CREATE INDEX IF NOT EXISTS idx_jobs_trade ON jobs(trade_required);
CREATE INDEX IF NOT EXISTS idx_jobs_city ON jobs(city);
CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
CREATE INDEX IF NOT EXISTS idx_applications_job ON applications(job_id);
CREATE INDEX IF NOT EXISTS idx_applications_worker ON applications(worker_id);
