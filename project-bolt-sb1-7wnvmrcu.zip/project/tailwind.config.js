/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#fef7f3',
          100: '#fceee3',
          200: '#f8d9c4',
          300: '#f3b899',
          400: '#ea8c62',
          500: '#C84B11',
          600: '#a93c0d',
          700: '#8b310b',
          800: '#6f280a',
          900: '#592009',
        },
        secondary: {
          50: '#f5f7fa',
          100: '#e4e9f0',
          200: '#cdd4e1',
          300: '#a8b8cb',
          400: '#7a96ae',
          500: '#5a7a95',
          600: '#496478',
          700: '#3d5261',
          800: '#344553',
          900: '#1E2A38',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
